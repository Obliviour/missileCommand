// External libs
#include "mbed.h"
#include "wave_player.h"
// #include "MMA8452.h" I don't need this
#include "PinDetect.h"
// Project includes
#include "globals.h"
#include "city_landscape_public.h"
#include "missile_public.h"
#include "player_public.h"
#include "testbench.h"
#include <cmath>

#define CITY_HIT_MARGIN 1
#define CITY_UPPER_BOUND (SIZE_Y-(LANDSCAPE_HEIGHT+MAX_BUILDING_HEIGHT))
#define PLAYER_COLOR 0x0000FF //blue

// Helper function declarations
void playSound(char* wav);

// Console output
Serial pc(USBTX,USBRX);

// Accelerometer
//MMA8452 accel(p28, p27, 100000);
AnalogIn xAcc(p20);
AnalogIn y(p19);
AnalogIn z(p17);

//LEDS
 DigitalOut myled1(LED1);
 DigitalOut myled2(LED2);
 DigitalOut myled3(LED3);
 DigitalOut myled4(LED4);

// Screen
uLCD_4DGL uLCD(p28, p27, p29); // serial tx, serial rx, reset pin;

// Speaker
AnalogOut DACout(p18); 
PwmOut speaker(p25);
wave_player waver(&DACout);

// SD Card
SDFileSystem sd(p5, p6, p7, p8, "sd"); // mosi, miso, sck, cs


//PinDetect Interrupts
bool toShoot = 0;
bool setL = 0;
bool setR = 0;
bool isQuit = 0;

void keyPress_pinL(void) {
    setL = 1;
    }
void keyPress_pinM(void) {
    toShoot = 1;
    }
void keyPress_pinR(void) {
    setR = 1;
    }
void keyPress_pinQ(void) {
    isQuit = !isQuit;
    }

PinDetect left_pb(p9, PullUp);
PinDetect fire_pb(p10, PullUp);
PinDetect right_pb(p11, PullUp);
PinDetect pinQ(p12, PullUp);

// User function definitions
bool checkRadius(int, int, int, int, int);
void bigBang(int, int, int, int);
void bigBang(int, int); 
void endGame();
void endGameWin();
void resetLED();
void runMainMenu();
bool runPlayAgain();
void runHighScore(int);

// User global definitions
Timer t;                            //> Reads time for multiple lives
 

    // Initialization goes here
    int radiusMissile = 10;             //> radius of explosion for a missile
    int delta_radiusMissile = 1;        //> change in radius per level
    //int radiusCity = 15;              //> radius of explosion for a city
    int numCity = 4;                    //> num of cities 
    int numCityLeft = numCity;          //> num of cities left
    int planeHit = 0;                   //> will tell if plane is hit or not
    int planeUpdater = 0;               //> will update the plane every few iterations
    int numMissHit = 0;                 //> keeps score
    int numLevel = 1;                   //> maintains level
    int speedMissile = 8;               //> sets speed (1-8)
    int delta_speedMissile = 1;         //> change in speed per lvl
    int intervalMissile = 50;           //> sets interval of Missiles (1-100)
    int delta_intervalMissile = 5;      //> change the interval per lvl
    int numLives = 1;                   //> num of lives the player has
    int topScore = 0;                   //> top Score
    int currentScore = 0;               //> current score
    int QUIT_GAME = 0;                  //> when true, game will completely quit
    int currTime = 0;                   //> used for multiple lives
    int isInvinsible = 0;               //> used to set player as invinsible
    int time_Invinsible;                //> used to manage how long invinsible
    /** Run this to check  the linked list
                            // Replace <outfile> with your student ID
                            test_dlinkedlist(
                                "/sd/tests/dll_test.txt",
                                "/sd/903035833.txt"
                            );
                        
                            // Test the speaker
                            playSound("/sd/wavfiles/BUZZER.wav");
    */

int main()
{
    
    /*
    //
    //   Startup Interrupts using PinDetect
    //
    */
    
    left_pb.attach_asserted( &keyPress_pinL );
    fire_pb.attach_asserted( &keyPress_pinM );
    right_pb.attach_asserted( &keyPress_pinR );
    pinQ.attach_asserted( &keyPress_pinQ );
    
    left_pb.setSampleFrequency(); // Defaults to 20ms.
    fire_pb.setSampleFrequency(); // Defaults to 20ms.
    right_pb.setSampleFrequency(); // Defaults to 20ms.
    pinQ.setSampleFrequency(); // Defaults to 20ms.
    
    
     /**************************************************************************
    //
    // OVERALL GAME LOOP              OVERALL GAME LOOP
    //               OVERALL GAME LOOP              OVERALL GAME LOOP
    // OVERALL GAME LOOP              OVERALL GAME LOOP
    //
    **************************************************************************/
    while(!QUIT_GAME) {
        // Initialization goes here
        radiusMissile = 10;             //> radius of explosion for a missile
        delta_radiusMissile = 1;        //> change in radius per level
        //int radiusCity = 15;          //> radius of explosion for a city
        numCity = 4;                    //> num of cities 
        numCityLeft = numCity;          //> num of cities left
        planeHit = 0;                   //> will tell if plane is hit or not
        planeUpdater = 0;               //> will update the plane every few iterations
        numMissHit = 0;                 //> keeps score
        numLevel = 1;                   //> maintains level
        speedMissile = 8;               //> sets speed (1-8)
        delta_speedMissile = 1;         //> change in speed per lvl
        intervalMissile = 50;           //> sets interval of Missiles (1-100)
        delta_intervalMissile = 5;      //> change the interval per lvl
        numLives = 1;                   //> num of lives the player has
        topScore = 0;                   //> top Score
        currentScore = 0;               //> current score
        QUIT_GAME = 0;                  //> when true, game will completely quit
        
        
        /*
        //
        //  Main Menu and Difficulty Level
        //
        */
        runMainMenu();
        
        //=== Reset switches ====
        wait(1);
        toShoot = 0;
        setL = 0;
        setR = 0;
        isQuit = 0;
        uLCD.cls();
        /*
        //
        //  Initialize Board and various Objects
        //
        */
        CITY ourCity;                       //> holding our city information
        PLAYER_MISSILE* pMissile = NULL;    //> holding the player missile
        MISSILE* eMissile = NULL;           //> holding the enemy missile
        DLinkedList* missileDLL = NULL;     //> holding the missiles list
        city_landscape_init(numCity);       //> creates a city with numCity cities
        player_init();                      //> creates the player
        PLAYER player = player_get_info();  //> gives us access to the structure of player
        missile_init();                     //> generate enemy missiles 
        resetLED();                         //> turns all LEDs on 
        
        t.start();                          //> Start the timer
        
        /**************************************************************************
        //
        // MAIN GAME LOOP              MAIN GAME LOOP
        //               MAIN GAME LOOP              MAIN GAME LOOP
        // MAIN GAME LOOP              MAIN GAME LOOP
        //
        **************************************************************************/
        while(!isQuit)  //SELFNOTE: WhydidIput !toShoot inthewhileloop //> emergency quit on the 4th button
        {   
            /*
            //
            //   Special Powers (that use lives)
            //
            */
            if (numLives > 1) {
                if (setL && !setR) { //First superpower
                    //== CLEAR ALL MISSILES ====
                    MISSILE* newMissile = (MISSILE*)getHead(missileDLL);
                    //iterate over all missiles
                    while(newMissile)
                    {            
                            // clear the missile on the screen
                            missile_draw(newMissile, 0x000000);
                                        
                            // Remove it from the list
                            newMissile = (MISSILE*)deleteForward(missileDLL, 1);  
                    }
                    setL = 0;
                    numLives--;
                }
                if (setR && !setL) { //Second superpower
                    isInvinsible = 1;
                    time_Invinsible = (int) t.read();
                    setR = 0;
                    numLives--;
                }
            }
            //== Invinsible management ====
            if (isInvinsible) {
                if(time_Invinsible + 15 <= ((int) t.read())) {
                    myled1 = !myled1;
                    isInvinsible = 0;
                }
            }
            
            
            /*
            //
            //   Update Missiles, Player, and Lists
            //
            */
            
                            // Update missiles
            missile_generator();            //> generate enemy missile
            if(toShoot) {
                player_fire();              //> generate our missiles
                toShoot = 0;
                playSound("/sd/shotQ.wav"); //> this plays sound
                }
            if (getSize(player.playerMissiles))
                player_missile_draw();      //> draw our missiles
            
                            // Update player position
            if ((++planeUpdater)%1 == 0) {
                if(xAcc <= .73) player_moveLeft();
                if(xAcc >= .85) player_moveRight();
            }
             
                            // Update Lists 
            player = player_get_info();
            missileDLL = get_missile_list();
            
            /*
            //
            //   Multiple Live Functionality
            //
            */
            if (((int) t.read())% 30 == 0 && ((int)t.read()) != currTime) {
                numLives++;
                currTime = (int) t.read();
            }
            //Every 30 seconds, you gain another life
            
            /*
            //
            //   Update Scores and Text on Screen
            //
            */
            
            uLCD.locate(9,0);
            uLCD.printf("Score: %d",numMissHit);
            uLCD.locate(0,0);
            uLCD.printf("LvL %d", numLevel);
            uLCD.locate(0,1);
            uLCD.printf("Lives: %d", numLives);
            uLCD.locate(0,0);
            
            /*
            //
            //   Below Changes Level
            //
            */
            
            if (numMissHit == 10 || (setR && setL)) {
                uLCD.cls();                                     //> Clear Screen
                if (numLevel==8) break;                         //> End game if win
                set_landscapeColor(uLCD.rand_color());          //> Set Colors
                set_cityColor(uLCD.rand_color());               //>
                player_draw(player_setColor(uLCD.rand_color()));//> End Set Colors
                numLevel++;                                     //> Increase Lvl
                numMissHit = 0;                                 //> Reset Hit cnt
                speedMissile-=delta_speedMissile;               //> Change spd
                set_missile_speed(speedMissile);                //> Increase spd
                intervalMissile-=delta_intervalMissile;         //> Increase Iterval
                set_missile_interval(intervalMissile);          //> Set interval
                radiusMissile-=delta_radiusMissile;             //> Decrease Radius
                setR = 0;                                       //> Reset buttons
                setL = 0;                                       //> End Reset button
                draw_cities();                                  //> Draw Cities
                draw_landscape();                               //> Draw Landscape
               
            }
            
            
            
            /*
            //
            //   Below Checks through enemy missiles
            //
            */
            
            for ( int i  = 0; i < getSize(missileDLL); i++) {
                if (i == 0) {
                    eMissile = (MISSILE*)getHead(missileDLL);
                } else {
                    eMissile = (MISSILE*)getNext(missileDLL);
                }
                 /*
                //
                //   Checking if plane has been hit
                */
                 
                 if ( eMissile->x >= player.x && eMissile->x <= player.x + 12) {
                    if ( eMissile->y <= player.y && eMissile->y >= player.y - 10) {
                        playSound("/sd/shot.wav");
                        eMissile->status = MISSILE_EXPLODED; 
                        if (!isInvinsible) { //lets the player to be invinsible
                            planeHit = 1;
                            player_destroy();
                            //== CLEAR ALL MISSILES ====
                            MISSILE* newMissile = (MISSILE*)getHead(missileDLL);
                            //iterate over all missiles
                            while(newMissile)
                            {            
                                    // clear the missile on the screen
                                    missile_draw(newMissile, 0x000000);
                                                
                                    // Remove it from the list
                                    newMissile = (MISSILE*)deleteForward(missileDLL, 1);  
                            }
                        }
                    }
                }
                /*
                //
                //   Below Checks for collisions between cities and missiles
                //
                */
                for (int k = 0; k < numCity; k++) {
                    ourCity = city_get_info(k);
                    if (ourCity.status == DESTORIED) continue;
                    if ( eMissile->x >= ourCity.x + 1 && eMissile->x <= ourCity.x + ourCity.width) {
                        if (eMissile->y <= ourCity.y + 10 && eMissile->y >= ourCity.y - ourCity.height) {
                            switch (k) {
                                case 0:
                                    myled1 = !myled1;
                                    break;
                                case 1:
                                    myled2 = !myled2;
                                    break;
                                case 2:
                                    myled3 = !myled3;
                                    break;
                                case 3:
                                    myled4 = !myled4;
                                    break;
                            }
                            //pc.printf("CITYGONE\n");
                            // create little explosion from impact
                            bigBang(eMissile->x,eMissile->y);
                            city_destory(k);
                            eMissile->status = MISSILE_EXPLODED; 
                            playSound("/sd/shot.wav");
                            break;
                        }    
                    }
                }
                /*
                //
                //   Below Checks for collisions between missiles
                //
                */
                for (int j = 0; j < getSize(player.playerMissiles); j++) {
                     //pc.printf("pmd:checking loop");
                    if (j == 0) {
                        pMissile = (PLAYER_MISSILE*) getHead(player.playerMissiles);
                    } else {
                        pMissile = (PLAYER_MISSILE*) getNext(player.playerMissiles);
                    }
                    if (eMissile->status != MISSILE_EXPLODED) {
                        if (checkRadius(radiusMissile, pMissile->x, pMissile->y, eMissile->x, eMissile->y)) {
                            pMissile->status = PMISSILE_EXPLODED; //> missile to be removed
                            eMissile->status = MISSILE_EXPLODED;  //> missile to be removed
                            // create little explosion from impact
                            bigBang((pMissile->x + eMissile->x)/2 , (pMissile->y + eMissile->y)/2 );
                            //pc.printf("pmd:radius smaller\n");
                            ++numMissHit; //change score
                        }
                    }
                }
            }    
            
    
            //checking if all cities are gone
            for (int i = 0; i < numCity; i++) {
                ourCity = city_get_info(i);
                numCityLeft -= (ourCity.status == DESTORIED) ? 1 : 0;
            }
            // if all cities are gone or the plane was hit -- ENDGAME --
            if ( !numCityLeft || planeHit ) {
                if (--numLives == 0) {
                    isQuit = !isQuit;
                    
                } else {
                    uLCD.cls();
                    city_landscape_init(numCity);
                    player_init(); 
                    planeHit = 0;
                    resetLED();
                }
                    
            }
            numCityLeft = numCity;
        } //END MAIN GAME LOOP
        t.stop();                                   //Stops the timer
                
        /*
        //
        //   Calculate Score
        //
        */
        currentScore = numMissHit * 10 + (numLevel-1) * 10 * 10 - ((int)t.read() - 25);
        if (currentScore >= topScore) {
            topScore = currentScore;
            runHighScore(currentScore);
        }
        /*
        //
        //   Print some stuff on the screen
        //
        */
        (numLevel==8) ? endGameWin(): endGame();    //Ends Game if win or loss
        QUIT_GAME = runPlayAgain();
    } //END OVERALL_LOOP
    // ===User implementations end===
    uLCD.cls();
    uLCD.printf("thank you...");
    uLCD.printf("\nCome back and play!");
}

// ===User implementations start===
// Put helper functions here

/**
 * runHighScore()
 *
 * Celebrates the user getting a high score
 *
 * @param none
 */
void runHighScore(int score) {
    uLCD.cls();
    int ti = t.read_us();
    srand(ti);
    uLCD.locate(6,2);
    uLCD.printf("\tYOU\n\tACHIEVED\n\tA NEW\n\tHIGH SCORE");
    uLCD.printf("\n\tOF: %d",score);
    int numCircles = rand() % 20 + 10;
    for (int i = 0; i < numCircles; i++) {
        int x = rand() % 127 + 1;
        int y = rand() % 127 + 1;
        int startR = rand() % 20 + 5;
        int numCircle = rand() % 12 + 8;
        bigBang(x, y, startR, numCircle);
        uLCD.locate(6,2);
        uLCD.printf("\tYOU\n\tACHIEVED\n\tA NEW\n\tHIGH SCORE");
        uLCD.printf("\n\tOF: %d",score);
        uLCD.locate(0,0);
    }
    wait(1);
    uLCD.locate(0,0);
    uLCD.cls();
    
}

/**
 * runPlayAgain()
 *
 * Asks user if they would like to play again
 *
 * @param returns true/yes false/no
 */
 
bool runPlayAgain() {
    uLCD.printf("Would you like to play again?\n");
    uLCD.printf("\nPress p9 to play again or press P11 to stop");
    while( left_pb && right_pb);
    uLCD.cls();
    return (!left_pb) ? false : true; 
}


/**
 * checkRadius
 *
 * Takes in a int radius and comparing x/y cordinates to see if the missiles
 * will colide 
 *
 * @param r radius (distance between two cordinates)
 * @param x1/y1 : x2/y2 cordinates of the two missiles
 *
 */
bool checkRadius(int r, int x1, int y1, int x2, int y2) {
    //pc.printf("%d %d %d %d",x1,y1,x2,y2);
    r*=2; //For the diameter
    double xD = abs(x1 - x2);
    double yD = abs(y1 - y2);
    //(sqrt(xD*xD + yD*yD) <= r) ? pc.printf("true") : pc.printf("false");
    return sqrt(xD*xD + yD*yD) <= r; 
}

/**
 * bigBang
 *
 * creates a small amount of circles of random colors that come from the collision
 *
 * @param takes in the cordinates of the center of the circle
 */

void bigBang(int x, int y) {
    int startR = 3;                     //> starting radius - 1
    int numCircle = 5;                  //> number of circles that will appear
    for(int i = 0; i < numCircle; i++) {
        uLCD.circle(x , y, startR++ , uLCD.rand_color() );  //> color will always be colorfully random
    }
    startR = 3;   
    for(int i = 0; i < numCircle; i++) {
        uLCD.circle(x , y, startR++ , 0x000000 );
    }
}

void bigBang(int x, int y, int startR, int numCircle) {
    //int startR = 3;                     //> starting radius - 1
    //int numCircle = 5;                  //> number of circles that will appear
    int tempstartR = startR;
    for(int i = 0; i < numCircle; i++) {
        uLCD.circle(x , y, startR++ , uLCD.rand_color() );  //> color will always be colorfully random
    }
    startR = tempstartR;   
    for(int i = 0; i < numCircle; i++) {
        uLCD.circle(x , y, startR++ , 0x000000 );
    }
}

/**
 * endGame
 *
 * clears the screen and says game over on it
 *
 * @param none
 */

void endGame() {
    uLCD.cls();
    uLCD.locate(6,2);
    uLCD.printf("Game Over\n\n");
    uLCD.printf("         _____ \n");
    uLCD.printf("        {.   .}\n\n");
    uLCD.printf("          /-\\  \n");
    uLCD.printf("         ----- \n");
    uLCD.printf("\n      Try Again ");
    uLCD.printf("\n\n      Lasted %.2f",t.read());
    uLCD.printf("\n      Seconds");
    wait(4);
    uLCD.cls();
    uLCD.locate(0,0);
 }   
 
 /**
 * endGameWin
 *
 * clears the screen and says you won on it
 *
 * @param none
 */
 
 void endGameWin() {
    uLCD.cls();
    uLCD.locate(6,2);
    uLCD.printf("YOU WON ALL 8 LEVELS\n\n");
    uLCD.printf("         _____ \n");
    uLCD.printf("        {.   .}\n\n");
    uLCD.printf("          /-\\  \n");
    uLCD.printf("         ----- \n");
    uLCD.printf("\n      U good at life "); 
    uLCD.printf("\n\n      Took you %.2f",t.read());
    //uLCD.printf("\n     Seconds!");
    wait(4);
    uLCD.cls();
    uLCD.locate(0,0);
}

/**
 * resetLED
 *
 * clears all the LED colors when needed
 *
 * @param none
 */

void resetLED() {
    myled1 = 1;
    myled2 = 1;
    myled3 = 1;
    myled4 = 1;
}
 
 
/**
 * MainMenu()
 *
 * Allows user to pick difficulty level
 *
 * @param none
 */ 
 
void runMainMenu() {
    uLCD.printf("Welcome to my         little game!!\n");
    uLCD.printf("\nPress a button for     difficulty\n");
    uLCD.printf("     Easy (P9)\n");
    uLCD.printf("     Medium (P10)\n");
    uLCD.printf("     Hard (P11)\n");

    while (left_pb && fire_pb && right_pb) wait(.1); //> wait for a button to be pushed

    if (!left_pb) {
        numCity = 6;                    //> num of cities 
        numCityLeft = numCity;          //> num of cities left
        numLives = 3;                   //> num of lives the player has
        
        radiusMissile = 16;             //> radius of explosion for a missile
        delta_radiusMissile = 1;        //> change in radius per level
        speedMissile = 8;               //> sets speed (1-8)
        delta_speedMissile = 1;         //> change in speed per lvl
        intervalMissile = 100;          //> sets interval of Missiles (1-100)
        delta_intervalMissile = 5;      //> change the interval per lvl
        //EASY  MODE
    }
    if (!fire_pb) {
        numCity = 5;                    //> num of cities 
        numCityLeft = numCity;          //> num of cities left
        numLives = 2;                   //> num of lives the player has
        
        radiusMissile = 12;             //> radius of explosion for a missile
        delta_radiusMissile = 1;        //> change in radius per level
        speedMissile = 8;               //> sets speed (1-8)
        delta_speedMissile = 1;         //> change in speed per lvl
        intervalMissile = 75;           //> sets interval of Missiles (1-100)
        delta_intervalMissile = 5;      //> change the interval per lvl
        //MEDIUM MODE
    }
    if (!right_pb) {
        numCity = 4;                    //> num of cities 
        numCityLeft = numCity;          //> num of cities left
        numLives = 1;                   //> num of lives the player has
        
        
        radiusMissile = 9;             //> radius of explosion for a missile
        delta_radiusMissile = 1;        //> change in radius per level
        speedMissile = 8;               //> sets speed (1-8)
        delta_speedMissile = 1;         //> change in speed per lvl
        intervalMissile = 45;           //> sets interval of Missiles (1-100)
        delta_intervalMissile = 5;      //> change the interval per lvl
        //HARD MODE
    }
}     
// ===User implementations end===

// Plays a wavfile
void playSound(char* wav)
{
    //open wav file
    FILE *wave_file;
    wave_file=fopen(wav,"r");
    
    if(wave_file != NULL) 
    {
        printf("File opened successfully\n");

        //play wav file
        printf("Sound playing...\n");
        waver.play(wave_file);
    
        //close wav file
        printf("Sound stopped...\n");
        fclose(wave_file);
        return;
    }
    
    printf("Could not open file for reading - %s\n", wav);
    return;
}
